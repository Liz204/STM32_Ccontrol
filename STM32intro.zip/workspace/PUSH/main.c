#include "stm32f0xx.h"

void delay(int time){
	for (int i=0; i<time; i++); //for que har� un delay ANTIGUO
}
int main(void)
{
	//RCC->AHBENR |=(1<<19); //Inicializa el reloj del puerto c (DE ENTRADA)
	RCC->AHBENR |=RCC_AHBENR_GPIOCEN;
	//GPIOC->MODER |=(1<<16); //Inicializa el puerto del led de salida
	GPIOC->MODER |=GPIO_MODER_MODER8_0;
	//RCC->AHBENR |=(1<<19); //Inicializa el reloj del puerto c (DE ENTRADA)
	RCC->AHBENR |=RCC_AHBENR_GPIOAEN; //Inicializa reloj de botón

    while(1)
    {
    	//GPIOC->ODR |=(1<<8); //Otra manera de prender el led azul, (se recorre el 1)
    	//GPIOC->ODR |=GPIO_ODR_8; //Se prende el led azul que est� en el lugar binario8
    	//GPIOC->ODR &= ~GPIO_ODR_8; //Se utiliza un and para superponer el valor negado
    	//Si quisieramos apagar completamente el registro GPIO->ODR=0;
    	//delay(500000); //llamas a funci�n
    	while(RCC->IDR &GPIO_IDR_0 ==1)
    	{
    		GPIOC->ODR |=GPIO_ODR_8;
    	}
    	GPIOC->ODR &= ~GPIO_ODR_8;
    }
}

