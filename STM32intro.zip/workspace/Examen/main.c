#include "stm32f0xx.h"

int main(void)
{
	///////////**Configuración de PWM********////////
	RCC->APB2ENR |=RCC_APB2ENR_TIM1EN; //Habilitar reloj timer
	RCC->AHBENR |=RCC_AHBENR_GPIOAEN; //hABILITAR RELOJ EN PUERTO A
	GPIOA ->MODER |=GPIO_MODER_MODER8_1; //CONFIG PIN EN FUNCIÓN ALTERNATIVA 10
	GPIOA->AFR[1]|= 0X02;  //
	//FIN DE CONFIGURACIÓN DE PUERTO
	TIM1->PSC = 479+1; // PREESCALADOR A VELOCIDAD DE .1 khz
	TIM1->ARR=8;
	TIM1->CCR1=4; //tIEMPO EN ALTO 4+1 MS
	TIM1->CCMR1 |=TIM_CCMR1_OC1M_2 |TIM_CCMR1_OC1M_1; //PWM MODO 1 PARA QUE SE ESPERE A TOMAR NUEVOS DATOS
	TIM1->CCER |= TIM_CCER_CC1E;
	TIM1->BDTR |= TIM_BDTR_MOE;
	TIM1->CR1 |= TIM_CR1_CEN;
	TIM1->EGR |= TIM_EGR_UG;


	//////****Configuracion ADC CANAL 2 y seteo de led como output pwm***///////
	RCC->APB2ENR |=RCC_APB2ENR_TIM1EN; //Habilitar reloj timer
	RCC->AHBENR |=RCC_AHBENR_GPIOAEN; //hABILITAR RELOJ EN PUERTO A
	GPIOA ->MODER |=GPIO_MODER_MODER8_1; //CONFIG PIN EN FUNCI�N ALTERNATIVA 10
	GPIOA->AFR[1]|= 0X02;  //
		//FIN DE CONFIGURACI�N DE PUERTO
		//CONFIGURACI�N DE ENTRADA ADC
	RCC->APB2ENR |=RCC_APB2ENR_ADC1EN;  //Habilitas el reloj ADC
	RCC ->CR2 |= RCC_CR2_HSI14ON;  //Encuentras en el manual buscando ADC, tedice que HSI14 y buscas hasta encontrar un On o ennable

	while ((RCC->CR2 & RCC_CR2_HSI14RDY)==0); //Aseguras orden con una flag para checar que este el reloj
	/*CALIBRATION*/
	ADC1 ->CR &= ~(ADC_CR_ADEN); //Deshabilitar registro
	ADC1 ->CR |= ADC_CR_ADCAL;  //Calibra registro
	while((ADC1 ->CR & ADC_CR_ADCAL) !=0);	 //Checa que est� calibrado el registro
	ADC1->CR |= ADC_CR_ADEN;
			//ADC1 ->ISR |=ADC_ISR_ADRDY ;
	while(ADC1 ->ISR & ADC_ISR_ADRDY ==0); //Tiene que ser ADC1 porq hay varios relojes en la p�gina 97 del manual dice
	ADC1 ->CFGR1 |=ADC_CFGR1_AUTOFF; //(1<<15) Habilitaci�n del bajo consumo
	ADC1 ->CHSELR |= ADC_CHSELR_CHSEL2; //(1<<1) Establecer canal de entrada

	//CONFIGURACIÓN DE PA0 COMO INTERRUPCIÓN EXTERNA//
	RCC->AHBENR |=RCC_AHBENR_GPIOCEN;
		GPIOC->MODER |=GPIO_MODER_MODER8_0;
		RCC->AHBENR |= RCC_AHBENR_GPIOAEN;
		GPIOA->MODER &= ~GPIO_MODER_MODER0; //CONFIGURAR COMO ENTRADA PA0
		//REGISTRO DE INTERRPUCIONES EXTERNAS
		SYSCFG->EXTICR[0]=SYSCFG_EXTICR1_EXTI0_PA; //CONFIGURA PUERTO A
		EXTI->IMR |=EXTI_IMR_MR0; //EBNASCARANUEBTI
		EXTI-> RTSR |=EXTI_RTSR_TR0; //FLANCO DE SALIDA
		NVIC_SetPriority(EXTI0_1_IRQn,0); //Configura INTERRUPCI�N
		NVIC_EnableIRQ(EXTI0_1_IRQn); //Habilita interrupci�n
	    while(1)
	    {

	    }
}

void EXTI0_1_IRQHandler(void)
{
	EXTI->PR |=1;
	//GPIOC->ODR ^=GPIO_ODR_8;
	//PARA LEER EL VOLTAJE ADC DENTRO DE CANAL 2////
			//*******LECTURA ADC******////
	unsigned int ReadOne; //Para que tome puros positivo; //Para que tome puros positivo
	float DC;
	unsigned int CCRX;
	unsigned int NDC;
			ADC1 ->CR |= ADC_CR_ADSTART; //INICIA LA CONVERSI�N
			while (ADC1 ->ISR &  (ADC_ISR_EOC)==0);//END OF CONVERSION FLAG
			ReadOne=ADC1->DR;  //Guardar lectura de datos
			DC= (float)ReadOne/4095;
			//CCRX= DC*(8+1)-1;
			TIM1->PSC = 479; //48 Megahertz/ (47+1) PREESCALADOR A VELOCIDAD DE 1 MHZ
			TIM1->ARR=8;
				if (DC>=0.3){
				NDC=DC*1.25;
				CCRX=NDC*(9)-1;
				TIM1->CCR1=CCRX; //tIEMPO EN ALTO 3.5 +1 MS CCRX= 3.5
				}
				else{
					if(DC==0)
					{

					}
					else{
					NDC=DC*0.75;
					CCRX=NDC*(9)-1;
					TIM1->CCR1=CCRX; //tIEMPO EN ALTO 3.5 +1 MS CCRX= 3.5
					}
				}

}


