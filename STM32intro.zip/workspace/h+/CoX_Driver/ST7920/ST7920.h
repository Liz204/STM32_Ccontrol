//*****************************************************************************
//
//! \file ST7920.h
//! \brief
//! \version V0.1.0
//! \date 2/22/2013
//! \author Shadow(gzbkey)
//! \copy
//!
//! Copyright (c)  2012-2013, Shadow(gzbkey)
//! All rights reserved.
//
//*****************************************************************************

#ifndef _ST7920_H_
#define _ST7920_H_

//*****************************************************************************
//
//! \addtogroup CoX_Driver_Lib
//! @{
//
//*****************************************************************************

//*****************************************************************************
//
//! \addtogroup LCD
//! @{
//
//*****************************************************************************

//*****************************************************************************
//
//! \addtogroup LCD_Graphic
//! @{
//
//*****************************************************************************

//*****************************************************************************
//
//! \addtogroup ST7920
//! @{
//
//*****************************************************************************

#include "xhw_types.h"
#include "xhw_memmap.h"
#include "xhw_ints.h"
#include "xhw_nvic.h"
#include "xcore.h"
#include "xsysctl.h"
#include "xgpio.h"
#include "xspi.h"

//*****************************************************************************
//
//! ST7920 Device config, here must be configured before use the API.
//
//*****************************************************************************

//
//don't change it
//
#define SOFTWARE                0
#define HARDWARE                1
#define BACKLIGHT_OFF           0
#define BACKLIGHT_ON            1

//
//! use LCM12864
//
#define LCM12864

//
//! use SPI mode ,set HARDWARE or SOFTWARE
//
#define SPI_MODE                HARDWARE

//
//! Config the SPI port
//
#define ST7920_SPI_X            SPI2_BASE
#define ST7920_SPI_X_CLK        SPI2CLK(3)
#define ST7920_SPI_X_MOSI       SPI2MOSI(3)

//
//! Config SPI speed, don't set too large
//
#define SPI_CLOCK               20000


//
//! Software control the backlight.
//! If you want to control the backlight, you must turn it on
//
#define SOFTWARE_CTRL_BLK       BACKLIGHT_OFF

//
//! Config the SPI SCL PORT
//
#define ST7920_PORT             xSYSCTL_PERIPH_GPIOB

//
//! Config the SPI SCL pin
//
#define ST7920_SCLK             PB13//PA5

//
//! Config the SPI SID pin (MOSI)
//
#define ST7920_SID              PB15//PA7

//
//! Config the SPI CS pin
//
#define ST7920_CS               PB14//PA4

//
//! Config the backlight pin
//
#if SOFTWARE_CTRL_BLK
#define ST7920_BLK              PC3
#endif



//*****************************************************************************
//
//! ST7920 macro definition, do not change it
//
//*****************************************************************************
#define ST7920_SCLK_H           xGPIOSPinWrite(ST7920_SCLK,1)
#define ST7920_SCLK_L           xGPIOSPinWrite(ST7920_SCLK,0)

#define ST7920_SID_H            xGPIOSPinWrite(ST7920_SID,1)
#define ST7920_SID_L            xGPIOSPinWrite(ST7920_SID,0)

#define ST7920_CS_H             xGPIOSPinWrite(ST7920_CS,1)
#define ST7920_CS_L             xGPIOSPinWrite(ST7920_CS,0)

#if SOFTWARE_CTRL_BLK
#define ST7920_BLK_H            xGPIOSPinWrite(ST7920_BLK,1)
#define ST7920_BLK_L            xGPIOSPinWrite(ST7920_BLK,0)
#endif

#define ST7920_BLK_ON           1
#define ST7920_BLK_OFF          0
#define ST7920_CURSOR_ON        1
#define ST7920_CURSOR_OFF       0
#define ST7920_CURSOR_ON        1
#define ST7920_BLINK_OFF        0


//*****************************************************************************
//
//! ST7920 APIs
//
//*****************************************************************************
void ST7920Init(void);
#if SOFTWARE_CTRL_BLK
void ST7920Backlight(unsigned char ucBacklightSwitch);
#endif
void ST7920Cursor(unsigned char ucCursor, unsigned char ucBlink); //16bit
void ST7920Clear(void); //clear word
void ST7920DisplayClear(void); //clear picture
void ST7920String(unsigned char ucX, unsigned char ucY, const char *pcS);
void ST7920DisplayPicture(unsigned char *pucPic);
void ST7920RomNum(unsigned char ucX, unsigned char ucY, unsigned char ucNum);
void ST7920RomNum2(unsigned char ucX, unsigned char ucY, unsigned char ucNum);

void ST7920UserCN(unsigned char ucRow, unsigned char ucColumn,
        unsigned char ucChn); //32x32

void ST7920UserNum(unsigned char ucRow, unsigned char ucColumn,
        unsigned char ucNum); //16x32
void ST7920UserNumReverse(unsigned char ucRow, unsigned char ucColumn,
        unsigned char ucNum); //16x32

//*****************************************************************************
//
//! @}
//
//*****************************************************************************

//*****************************************************************************
//
//! @}
//
//*****************************************************************************

//*****************************************************************************
//
//! @}
//
//*****************************************************************************

//*****************************************************************************
//
//! @}
//
//*****************************************************************************

#endif //_ST7920_H_
