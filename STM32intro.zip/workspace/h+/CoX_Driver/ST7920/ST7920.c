//*****************************************************************************
//
//! \file ST7920.c
//! \brief
//! \version V0.2.0
//! \date 2013.1.25
//! \author Shadow(gzbkey)
//! \copy
//!
//! Copyright (c)  2012-2013, Shadow(gzbkey)
//! All rights reserved.
//
//*****************************************************************************

#include "ST7920.h"
#include "ST7920_Font.h"
#include "ST7920_Picture.h"

enum ST7920_CMD_DAT {
	cmd, dat
} ST7920_CMD, ST7920_DAT;

//*****************************************************************************
//
//! \brief Delay ms for ST7920
//!
//! \param usTime is delay value.
//!
//! \return None.
//
//*****************************************************************************
void ST7920DelayMs(unsigned short int usTime) {
	unsigned short int i, j;
	for (i = 0; i < usTime; i++)
		for (j = 0; j < 10; j++)
			;
}

//*****************************************************************************
//
//! \brief A delay pulse period
//!
//! \param ucLevel is level value.
//!
//! High level or low level + delay
//! 1: high level
//! 0: low level
//!
//! \return None.
//
//*****************************************************************************
void ST7920SclkLevel(unsigned char ucLevel) {
	unsigned char ucTime;
	if (ucLevel)
		ST7920_SCLK_H;
	else
		ST7920_SCLK_L;
	ucTime = 0x50;
	while (ucTime--)
		;
}

//*****************************************************************************
//
//! \brief Send 8bit data to ST7920
//!
//! \param ucByte is 8bit data.
//!
//! \return None.
//
//*****************************************************************************
void ST7920SendByte(unsigned char ucByte) {
	int i;
	for (i = 0; i < 8; i++) {
		if (ucByte & 0x80) {
			ST7920_SID_H;
		} else {
			ST7920_SID_L;
		}
		ST7920SclkLevel(1);
		ST7920SclkLevel(0);
		ucByte <<= 1;
	}
}

//*****************************************************************************
//
//! \brief Send data or command to ST7920
//!
//! \param ucDatOrCmd decide send data or command.
//! \param ucSendByte is data(8bit) or command(8bit).
//!
//! ucDatOrCmd can be ST7920_DAT or ST7920_CMD
//!
//! \return None.
//
//*****************************************************************************
void ST7920Write(unsigned char ucDatOrCmd, unsigned char ucSendByte) {
#if SPI_MODE==SOFTWARE
	unsigned char byte_H, byte_L;

	ST7920_CS_H;

	if (ucDatOrCmd == ST7920_CMD) {
		ST7920SendByte(0xf8);
	} else {
		ST7920SendByte(0xfa);
	}

	byte_H = ucSendByte & 0xf0;
	byte_L = (ucSendByte << 4) & 0xf0;

	ST7920SendByte(byte_H);
	ST7920SclkLevel(0);

	ST7920SendByte(byte_L);

	ST7920_CS_L;

#else
	unsigned char cmd_d = 0xf8;
	unsigned char dat_d = 0xfa;
	unsigned char byte_H, byte_L;
	xGPIOSPinWrite(ST7920_CS, 1);

	if (ucDatOrCmd == ST7920_CMD) {
		xSPIDataWrite(ST7920_SPI_X, &cmd_d, 1);
	} else {
		xSPIDataWrite(ST7920_SPI_X, &dat_d, 1);
	}

	byte_H = ucSendByte & 0xf0;
	byte_L = (ucSendByte << 4) & 0xf0;

	xSPIDataWrite(ST7920_SPI_X, &byte_H, 1);

	xSPIDataWrite(ST7920_SPI_X, &byte_L, 1);

	xGPIOSPinWrite(ST7920_CS, 0);
#endif

}

//*****************************************************************************
//
//! \brief Initialization ST7920
//!
//! \return None.
//
//*****************************************************************************
void ST7920Init(void) {
	ST7920DelayMs(500);

	//
	// Enable the GPIOx port
	//
	xSysCtlPeripheralEnable( ST7920_PORT);
	//  xSysCtlPeripheralEnable( xGPIOSPinToPeripheralId(ST7920_SCLK) );

#if SPI_MODE==SOFTWARE

	xGPIOSPinTypeGPIOOutput(ST7920_SCLK);
	xGPIOSPinTypeGPIOOutput(ST7920_CS);
	xGPIOSPinTypeGPIOOutput(ST7920_SID);

#else //SPI_MODE==HARDWARE
	//
	// Enable Peripheral SPIx
	//
	xSysCtlPeripheralEnable2(ST7920_SPI_X);

	// Configure Some GPIO pins as output
	//
	xGPIOSPinTypeGPIOOutput(ST7920_CS);

	//
	// Configure Some GPIO pins as SPI Mode
	//
	xSPinTypeSPI(ST7920_SPI_X_CLK, ST7920_SCLK);
	xSPinTypeSPI(ST7920_SPI_X_MOSI, ST7920_SID);
	xSPIConfigSet(ST7920_SPI_X, SPI_CLOCK,
			xSPI_MOTO_FORMAT_MODE_0 | xSPI_MODE_MASTER | xSPI_MSB_FIRST | xSPI_DATA_WIDTH8);
	xSPISSSet(ST7920_SPI_X, xSPI_SS_SOFTWARE, 0);
	xSPIEnable(ST7920_SPI_X);
#endif

#if SOFTWARE_CTRL_BLK
	xGPIOSPinTypeGPIOOutput(ST7920_BLK);
	ST7920_BLK_L;
#endif

	ST7920_DAT = dat;
	ST7920_CMD = cmd;

	ST7920DelayMs(50);
	ST7920Write(ST7920_CMD, 0x30);
	ST7920DelayMs(50);
	ST7920Write(ST7920_CMD, 0x30);
	ST7920DelayMs(50);
	ST7920Write(ST7920_CMD, 0x0C);
	ST7920DelayMs(50);
	ST7920Write(ST7920_CMD, 0x01);
	ST7920DelayMs(50);
	ST7920Write(ST7920_CMD, 0x06);
}

//*****************************************************************************
//
//! \brief Backlight switch of ST7920
//!
//! \param ucBacklightSwitch is switch,control the backlight
//!
//! ucBacklightSwitch can be ST7920_BLK_ON or ST7920_BLK_OFF
//!
//! \return None.
//
//*****************************************************************************
#if SOFTWARE_CTRL_BLK
void ST7920Backlight(unsigned char ucBacklightSwitch)/*1 on  0 off*/
{
	if (ucBacklightSwitch)
	ST7920_BLK_L;
	else
	ST7920_BLK_H;
}
#endif
//*****************************************************************************
//
//! \brief Set cursor of ST7920
//!
//! \param ucCursor is Cursor ON/OFF control switch
//! \param ucBlink is Blink ON/OFF control switch
//!
//!  When ucCursor = ST7920_CURSOR_ON, cursor ON.
//!  When ucCursor = ST7920_CURSOR_OFF, cursor OFF.
//!
//!  When ucBlink = ST7920_CURSOR_ON, cursor position blink ON.
//!  When ucBlink = ST7920_CURSOR_OFF, cursor position blink OFF.
//!
//! \return None.
//
//*****************************************************************************
void ST7920Cursor(unsigned char ucCursor, unsigned char ucBlink) {
	unsigned char ucTempCmd = 0x0c;
	ucTempCmd = ucTempCmd + (ucCursor << 1) + ucBlink;

	ST7920Write(ST7920_CMD, 0x30);
	ST7920DelayMs(10);
	ST7920Write(ST7920_CMD, ucTempCmd);
	ST7920DelayMs(10);
	ST7920Write(ST7920_CMD, 0x30);
}

//*****************************************************************************
//
//! \brief Clear the srceen of ST7920
//!
//! \return None.
//
//*****************************************************************************
void ST7920Clear(void) {
	ST7920Write(ST7920_CMD, 0x30);
	ST7920DelayMs(10);
	ST7920Write(ST7920_CMD, 0x01);
	ST7920DelayMs(10);
	ST7920Write(ST7920_CMD, 0x30);
}

//*****************************************************************************
//
//! \brief Setting the display position
//!
//! \param ucX is row
//! \param ucY is column
//!
//! (12864)
//! ucX: 0-3
//! ucY: 0-15
//! (12832)
//! ucX: 0-1
//! ucY: 0-15
//! (12232)
//! ucX: 0-1
//! ucY: 0-14
//!
//! row and column Convert to address
//!
//! \return None.
//
//*****************************************************************************
void ST7920SetAddress(unsigned char ucX, unsigned char ucY) {
	unsigned char ucAddress;
	switch (ucX) {
	case 0:
		ucX = 0x80;
		break;
	case 1:
		ucX = 0x90;
		break;
	case 2:
		ucX = 0x88;
		break;
	case 3:
		ucX = 0x98;
		break;
	default:
		break;
	}
	ucAddress = ucX + ucY;
	ST7920Write(ST7920_CMD, ucAddress);
}

//*****************************************************************************
//
//! \brief Display the string within CGROM(chinese) or HCGROM(english)
//!
//! \param ucX is row
//! \param ucY is column
//! \param *pcS is string
//!
//! \return None.
//
//*****************************************************************************
void ST7920String(unsigned char ucX, unsigned char ucY, const char *pcS) {
	ST7920SetAddress(ucX, ucY);

	while (*pcS) {
		ST7920Write(ST7920_DAT, *pcS);
		pcS++;
		ST7920DelayMs(1);
	}
}

//*****************************************************************************
//
//! \brief Display a number within HCGROM
//!
//! \param ucX is row
//! \param ucY is column
//! \param *pcS is number (0-9)
//!
//! \return None.
//
//*****************************************************************************
void ST7920RomNum(unsigned char ucX, unsigned char ucY, unsigned char ucNum) {
	ST7920SetAddress(ucX, ucY);
	ST7920Write(ST7920_DAT, zk_num[ucNum]);
	ST7920DelayMs(1);
}

//*****************************************************************************
//
//! \brief Display a number within HCGROM
//!
//! \param ucX is row
//! \param ucY is column
//! \param *pcS is number (0-99)
//!
//! \return None.
//
//*****************************************************************************
void ST7920RomNum2(unsigned char ucX, unsigned char ucY, unsigned char ucNum) {
	unsigned char m = 0, n = 0;

	m = ucNum / 10;
	n = ucNum % 10;
	ST7920SetAddress(ucX, ucY);
	ST7920Write(ST7920_DAT, zk_num[m]);
	ST7920DelayMs(1);
	ST7920Write(ST7920_DAT, zk_num[n]);
	ST7920DelayMs(1);

}

//*****************************************************************************
//
//! \brief Display a picture
//!
//! \param *pucPic is array of picture data
//!
//! \return None.
//
//*****************************************************************************
void ST7920DisplayPicture(unsigned char *pucPic) {
	unsigned char i, j;
	ST7920Write(ST7920_CMD, 0x34);
	ST7920Write(ST7920_CMD, 0x36);

	for (i = 0; i < 32; i++) {
		ST7920Write(ST7920_CMD, 0x80 + i);
		ST7920Write(ST7920_CMD, 0x80);
		for (j = 0; j < 16; j++) {
			ST7920Write(ST7920_DAT, *pucPic);
			pucPic++;
		}
	}
#ifdef LCM12864
	for (i = 0; i < 32; i++) {
		ST7920Write(ST7920_CMD, 0x80 + i);
		ST7920Write(ST7920_CMD, 0x88);
		for (j = 0; j < 16; j++) {
			ST7920Write(ST7920_DAT, *pucPic);
			pucPic++;
		}
	}
#endif
	ST7920Write(ST7920_CMD, 0x30);
}

//*****************************************************************************
//
//! \brief Display a Chinese character (32*32)
//!
//! \param ucX is row
//! \param ucY is column
//! \param ucChn is Chinese sequence number
//!
//! user_cn[ucChn][]is array of Chinese data
//!
//! \return None.
//
//*****************************************************************************
void ST7920UserCN(unsigned char ucRow, unsigned char ucColumn,
		unsigned char ucChn) {
	unsigned int x = 0;
	unsigned char i, j;
	ST7920Write(ST7920_CMD, 0x34);
	ST7920Write(ST7920_CMD, 0x36);
	if (ucRow == 0)
		for (i = 0; i < 32; i++) {
			ST7920Write(ST7920_CMD, 0x80 + i);
			ST7920Write(ST7920_CMD, 0x80 + ucColumn);
			for (j = 0; j < 4; j++) {
				ST7920Write(ST7920_DAT, user_cn[ucChn][x]);
				x++;
			}
		}
	if (ucRow == 1) {
		for (i = 0; i < 16; i++) {
			ST7920Write(ST7920_CMD, 0x90 + i);
			ST7920Write(ST7920_CMD, 0x90 + ucColumn);
			for (j = 0; j < 4; j++) {
				ST7920Write(ST7920_DAT, user_cn[ucChn][x]);
				x++;
			}
		}
		for (i = 0; i < 16; i++) {
			ST7920Write(ST7920_CMD, 0x80 + i);
			ST7920Write(ST7920_CMD, 0x88 + ucColumn);
			for (j = 0; j < 4; j++) {
				ST7920Write(ST7920_DAT, user_cn[ucChn][x]);
				x++;
			}
		}
	}

	if (ucRow == 2)
		for (i = 0; i < 32; i++) {
			ST7920Write(ST7920_CMD, 0x80 + i);
			ST7920Write(ST7920_CMD, 0x88 + ucColumn);
			for (j = 0; j < 4; j++) {
				ST7920Write(ST7920_DAT, user_cn[ucChn][x]);
				x++;
			}
		}

	ST7920Write(ST7920_CMD, 0x30);
}

//*****************************************************************************
//
//! \brief Display a number (16*32)
//!
//! \param ucX is row
//! \param ucY is column
//! \param ucChn is a number for display
//!
//!
//! \return None.
//
//*****************************************************************************
void ST7920UserNum(unsigned char ucRow, unsigned char ucColumn,
		unsigned char ucNum) {
	unsigned int x = 0;
	unsigned char i, j;

	ST7920Write(ST7920_CMD, 0x34);
	ST7920Write(ST7920_CMD, 0x36);
	if (ucRow == 0)
		for (i = 0; i < 32; i++) {
			ST7920Write(ST7920_CMD, 0x80 + i);
			ST7920Write(ST7920_CMD, 0x80 + ucColumn);
			for (j = 0; j < 2; j++) {
				ST7920Write(ST7920_DAT, user_num[ucNum][x]);
				x++;
			}
		}
	if (ucRow == 1) {
		for (i = 0; i < 16; i++) {
			ST7920Write(ST7920_CMD, 0x90 + i);
			ST7920Write(ST7920_CMD, 0x90 + ucColumn);
			for (j = 0; j < 2; j++) {
				ST7920Write(ST7920_DAT, user_num[ucNum][x]);
				x++;
			}
		}
		for (i = 0; i < 16; i++) {
			ST7920Write(ST7920_CMD, 0x80 + i);
			ST7920Write(ST7920_CMD, 0x88 + ucColumn);
			for (j = 0; j < 2; j++) {
				ST7920Write(ST7920_DAT, user_num[ucNum][x]);
				x++;
			}
		}
	}

	if (ucRow == 2)
		for (i = 0; i < 32; i++) {
			ST7920Write(ST7920_CMD, 0x80 + i);
			ST7920Write(ST7920_CMD, 0x88 + ucColumn);
			for (j = 0; j < 2; j++) {
				ST7920Write(ST7920_DAT, user_num[ucNum][x]);
				x++;
			}
		}
	ST7920Write(ST7920_CMD, 0x30);
}

//*****************************************************************************
//
//! \brief Reverse display a number (16*32)
//!
//! \param ucX is row
//! \param ucY is column
//! \param ucChn is a number for display
//!
//!
//! \return None.
//
//*****************************************************************************
void ST7920UserNumReverse(unsigned char ucRow, unsigned char ucColumn,
		unsigned char ucNum) {
	unsigned int x = 0;
	unsigned char i, j;

	ST7920Write(ST7920_CMD, 0x34);
	ST7920Write(ST7920_CMD, 0x36);
	if (ucRow == 0)
		for (i = 0; i < 32; i++) {
			ST7920Write(ST7920_CMD, 0x80 + i);
			ST7920Write(ST7920_CMD, 0x80 + ucColumn);
			for (j = 0; j < 2; j++) {
				ST7920Write(ST7920_DAT, ~user_num[ucNum][x]);
				x++;
			}
		}
	if (ucRow == 1) {
		for (i = 0; i < 16; i++) {
			ST7920Write(ST7920_CMD, 0x90 + i);
			ST7920Write(ST7920_CMD, 0x90 + ucColumn);
			for (j = 0; j < 2; j++) {
				ST7920Write(ST7920_DAT, ~user_num[ucNum][x]);
				x++;
			}
		}
		for (i = 0; i < 16; i++) {
			ST7920Write(ST7920_CMD, 0x80 + i);
			ST7920Write(ST7920_CMD, 0x88 + ucColumn);
			for (j = 0; j < 2; j++) {
				ST7920Write(ST7920_DAT, ~user_num[ucNum][x]);
				x++;
			}
		}
	}

	if (ucRow == 2)
		for (i = 0; i < 32; i++) {
			ST7920Write(ST7920_CMD, 0x80 + i);
			ST7920Write(ST7920_CMD, 0x88 + ucColumn);
			for (j = 0; j < 2; j++) {
				ST7920Write(ST7920_DAT, ~user_num[ucNum][x]);
				x++;
			}
		}

	ST7920Write(ST7920_CMD, 0x30);
}

//*****************************************************************************
//
//! \brief Clear the srceen and display white srceen
//!
//! \return None.
//
//*****************************************************************************
void ST7920DisplayClear(void) {
	unsigned char i, j;
	ST7920Clear();

	ST7920Write(ST7920_CMD, 0x34);
	ST7920Write(ST7920_CMD, 0x36);
	for (i = 0; i < 32; i++) {
		ST7920Write(ST7920_CMD, 0x80 + i);
		ST7920Write(ST7920_CMD, 0x80);
		for (j = 0; j < 16; j++) {
			ST7920Write(ST7920_DAT, 0x00);
		}
	}
#ifdef LCM12864
	for (i = 0; i < 32; i++) {
		ST7920Write(ST7920_CMD, 0x80 + i);
		ST7920Write(ST7920_CMD, 0x88);
		for (j = 0; j < 16; j++) {
			ST7920Write(ST7920_DAT, 0x00);
		}
	}
#endif
	ST7920Write(ST7920_CMD, 0x30);
}

