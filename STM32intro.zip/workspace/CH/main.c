#include <stdio.h>
#include "stm32f0xx.h"

int main(void)
{
	/*********************** HABILITACI�N DE LOS LEDS ***********************/
	//Habilitamos la se�al de reloj de nuestra tarjeta ubicada en el puerto C
	RCC -> AHBENR |= RCC_AHBENR_GPIOCEN;
	//Habilitamos el led azul y verde como salida
	GPIOC -> MODER |= GPIO_MODER_MODER8_0 | GPIO_MODER_MODER9_0;
	/***********************************************************************/

	//Habilitamos la se�al de reloj el ADC
	RCC -> APB2ENR |= RCC_APB2ENR_ADC1EN; //RCC -> APB2ENR |= (1<<9)
	//Habilitamos un reloj del ADC en especifico
	RCC -> CR2 |= RCC_CR2_HSI14ON; //1

	//Comparamos que este lista la se�al de reloj del ADC para utlizarlo
	while ((RCC -> CR2 & RCC_CR2_HSI14RDY) == 0);

	/*********************** CALIBRACI�N ***********************/
	//Confirmamos que el ADC enable este deshabilitado para la calibracion
	ADC1 -> CR &= ~ADC_CR_ADEN;
	//Se realiza la calibraci�n del ADC
	ADC1 -> CR |= ADC_CR_ADCAL;
	//Esperamos a que se termine de calibrar
	while ((ADC1 -> CR & ADC_CR_ADCAL)!=0);
	/**********************************************************/

	/*********************** HABILITACI�N *********************/
	//Confirmamos que el ADC enable este deshabilitado para la calibracion
	ADC1 -> CR |= ADC_CR_ADEN;
	//Confirmamos que este la bandera activada
	while ((ADC1 -> ISR & ADC_ISR_ADRDY)==0);
	/**********************************************************/

	/********************* CONFIGURACI�N **********************/
	//Habilita o deshabilita el modo de consumo bajo
	ADC1 -> CFGR1 |= ADC_CFGR1_AUTOFF;// se le manda un 1
	// Canal a utilizar 2 y 3
	ADC1 -> CHSELR |= ADC_CHSELR_CHSEL2 | ADC_CHSELR_CHSEL3;
	// Canal a utilizar 4 (1<<15)
	//ADC1 -> CHSELR |= ADC_CHSELR_CHSEL3;
	//Rapidez de lectura del ADC//ADC1 -> SMPR |= 0x7; //0b111, 7

	//Lea numeros negativos
	unsigned int analogRead2;
	unsigned int analogRead3;

    while(1)
    {
    	//Inicia la conversi�n
    	ADC1 -> CR |= ADC_CR_ADSTART;
    	//Confirmacion de que a iniciado la lectura
    	while ((ADC1 -> ISR & ADC_ISR_EOC) ==0);
    	analogRead2 = ADC1 -> DR;
    	while ((ADC1 -> ISR & ADC_ISR_EOC) ==0);
    	analogRead3 = ADC1 -> DR;

    	/********************* COMPARACI�N DE VOLTAJES *********************/
    	if (analogRead2 > analogRead3)
    	{
    		//El led verde debe de prender con las mismas instrucciones
    		GPIOC -> ODR |= GPIO_ODR_9;
    		//Secuencia de apagado del led azul conforme a la se�al de reloj
    		GPIOC -> ODR &= ~GPIO_ODR_8;
    	}
    	else if (analogRead2 < analogRead3)
    	{
    		//El led azul debe de prender con las mismas instrucciones
    		GPIOC -> ODR |= GPIO_ODR_8;
    		//Secuencia de apagado del led verde conforme a la se�al de reloj
    		GPIOC -> ODR &= ~GPIO_ODR_9;
    	}
    	else
    	{
    		//El led verde y azul debe de prender con las mismas instrucciones
    		GPIOC -> ODR |= GPIO_ODR_8 | GPIO_ODR_9;
    	}
    	/********************************************************************/
    }
}
