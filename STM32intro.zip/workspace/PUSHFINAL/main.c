#define color 0x33

int suma(int l)

{

   return l+5;

}

int main()

{

  int result_if;

   int n=6;

   suma(n);

printf("Resultado de la suma %d",suma(n));

if(color==24)    //primer if

{

   result_if=24;

}

if(color==51)

{

   result_if=51;

}

if(color&(1<<5) )   //tercer if

{

   result_if=1;

}

printf("Resultado de la comparación %d",(color&(1<<5)));   //Inciso d)

}

